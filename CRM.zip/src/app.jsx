const { useState, useEffect } = React;

function App() {
  const defaults = window.__TWEAKS || {};
  const [tweaks, setTweaks] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("cetem-tweaks") || "null");
      return { ...defaults, ...(saved || {}) };
    } catch { return { ...defaults }; }
  });
  const [page, setPage] = useState(() => localStorage.getItem("cetem-page") || "pipeline");
  const [leads, setLeads] = useState(LEADS);
  const [openId, setOpenId] = useState(null);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.dataset.accent = tweaks.accent;
    document.documentElement.dataset.density = tweaks.density;
    localStorage.setItem("cetem-tweaks", JSON.stringify(tweaks));
  }, [tweaks]);

  useEffect(() => { localStorage.setItem("cetem-page", page); }, [page]);

  // Edit mode protocol — register listener first, then announce availability
  useEffect(() => {
    const onMsg = (e) => {
      if (!e.data || typeof e.data !== "object") return;
      if (e.data.type === "__activate_edit_mode")   { setEditMode(true); setTweaksOpen(true); }
      if (e.data.type === "__deactivate_edit_mode") { setEditMode(false); setTweaksOpen(false); }
    };
    window.addEventListener("message", onMsg);
    try { window.parent.postMessage({ type: "__edit_mode_available" }, "*"); } catch {}
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const setTweak = (k, v) => {
    setTweaks(t => {
      const next = { ...t, [k]: v };
      try { window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [k]: v } }, "*"); } catch {}
      return next;
    });
  };

  const onMove = (leadId, stage) => {
    setLeads(ls => ls.map(l => l.id === leadId ? { ...l, stage } : l));
  };
  const onStage = (stage) => {
    if (!openId) return;
    setLeads(ls => ls.map(l => l.id === openId ? { ...l, stage } : l));
  };

  const openLead = leads.find(l => l.id === openId);

  if (tweaks.device === "mobile") {
    return <>
      <MobileView />
      {(tweaksOpen || editMode) && <TweaksPanel tweaks={tweaks} setTweak={setTweak} onClose={() => setTweaksOpen(false)} />}
      {!tweaksOpen && !editMode && (
        <button className="btn" style={{position:"fixed", right:16, bottom:16, zIndex:70}} onClick={() => setTweaksOpen(true)}>
          <Icons.sparkle size={13}/> Tweaks
        </button>
      )}
    </>;
  }

  return (
    <div className="app">
      <Sidebar page={page} onNav={(p) => { setPage(p); setOpenId(null); }} />
      <div className="main">
        <Topbar
          page={page}
          onTweaks={() => setTweaksOpen(o => !o)}
          pipelineView={tweaks.pipelineView}
          setPipelineView={(v) => setTweak("pipelineView", v)}
          onAddLead={() => setPage("prospect")}
        />
        <div className="page">
          {page === "dashboard" && <Dashboard />}
          {page === "pipeline" && (
            tweaks.pipelineView === "kanban"
              ? <Pipeline view="kanban" leads={leads} onMove={onMove} onOpen={setOpenId} />
              : <Pipeline view={tweaks.pipelineView} leads={leads} onMove={onMove} onOpen={setOpenId} />
          )}
          {page === "leads" && <LeadsTable leads={leads} onOpen={setOpenId} />}
          {page === "prospect" && <Prospecting />}
          {page === "inbox" && <InboxPlaceholder />}
          {page === "sequences" && <SequencesPlaceholder />}
          {page === "reports" && <ReportsPlaceholder />}
        </div>
      </div>

      {openLead && <LeadDetail lead={openLead} onClose={() => setOpenId(null)} onStage={onStage} />}
      {(tweaksOpen || editMode) && <TweaksPanel tweaks={tweaks} setTweak={setTweak} onClose={() => setTweaksOpen(false)} />}
    </div>
  );
}

function InboxPlaceholder() {
  return (
    <div className="page-pad">
      <div className="page-head">
        <div>
          <div style={{fontSize:11, color:"var(--c-ink-3)", textTransform:"uppercase", letterSpacing:".06em"}}>Unificada</div>
          <h1>Caixa de entrada</h1>
          <div className="sub">E-mail, WhatsApp e LinkedIn em um fluxo único · 9 não lidas</div>
        </div>
      </div>
      <div className="card">
        <div className="card-bd" style={{padding:0}}>
          {ACTIVITIES.concat(ACTIVITIES).map((a,i) => (
            <div key={i} style={{display:"grid", gridTemplateColumns:"28px 200px 1fr 120px", gap:12, padding:"14px 18px", borderBottom:"1px solid var(--c-line)", alignItems:"center", cursor:"pointer"}}>
              <div className={"ic " + a.type} style={{width:28, height:28, borderRadius:6, display:"grid", placeItems:"center"}}>
                {a.type === "email" && <Icons.mail size={14}/>}
                {a.type === "call" && <Icons.phone size={14}/>}
                {a.type === "whats" && <Icons.message size={14}/>}
                {a.type === "meet" && <Icons.calendar size={14}/>}
                {a.type === "note" && <Icons.flame size={14}/>}
                {a.type === "stage" && <Icons.trending size={14}/>}
              </div>
              <div>
                <div style={{fontSize:13, fontWeight:500}}>{a.lead}</div>
                <div style={{fontSize:11, color:"var(--c-ink-3)"}}>{a.who}</div>
              </div>
              <div style={{fontSize:12.5, color:"var(--c-ink-2)"}}>{a.what}</div>
              <div className="mono dim" style={{fontSize:11, textAlign:"right"}}>{a.when}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SequencesPlaceholder() {
  const cadences = [
    { n: "Outbound SP — Logística", steps: 7, active: 24, reply: "18%", open: "62%" },
    { n: "Inbound qualificação rápida", steps: 4, active: 12, reply: "34%", open: "78%" },
    { n: "Reengajamento · leads frios 60d", steps: 5, active: 38, reply: "9%", open: "41%" },
    { n: "ABM Enterprise", steps: 9, active: 6, reply: "22%", open: "71%" },
  ];
  return (
    <div className="page-pad">
      <div className="page-head">
        <div>
          <h1>Cadências</h1>
          <div className="sub">Sequências automáticas de prospecção e follow-up</div>
        </div>
        <button className="btn primary"><Icons.plus size={13}/> Nova cadência</button>
      </div>
      <div className="grid-2">
        {cadences.map((c,i) => (
          <div key={i} className="card">
            <div className="card-hd">
              <Icons.bolt size={13} style={{color:"var(--c-accent)"}}/>
              <h3>{c.n}</h3>
              <span className="chip good" style={{marginLeft:"auto"}}><span className="dot"/>ativa</span>
            </div>
            <div className="card-bd">
              <div style={{display:"flex", gap:4, marginBottom:12}}>
                {Array.from({length: c.steps}).map((_,j) => (
                  <div key={j} style={{flex:1, height:8, borderRadius:4, background: j < 2 ? "var(--c-accent)" : "var(--c-line)"}}/>
                ))}
              </div>
              <div style={{display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:10}}>
                <div><div className="dim" style={{fontSize:11}}>Leads ativos</div><div className="mono" style={{fontSize:18}}>{c.active}</div></div>
                <div><div className="dim" style={{fontSize:11}}>Taxa de resposta</div><div className="mono" style={{fontSize:18}}>{c.reply}</div></div>
                <div><div className="dim" style={{fontSize:11}}>Abertura</div><div className="mono" style={{fontSize:18}}>{c.open}</div></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ReportsPlaceholder() {
  return (
    <div className="page-pad">
      <div className="page-head">
        <div><h1>Relatórios</h1><div className="sub">Performance do time · Q2 · 2026</div></div>
      </div>
      <div className="kpi-row">
        <KPI label="Ganhos Q2"         value="R$ 2,4M" delta="+22%" up spark={[4,5,6,7,6,8,9,11,12,11,13,14]}/>
        <KPI label="Win rate"          value="28,4%"   delta="+3,1pp" up />
        <KPI label="Ciclo de venda"    value="42 d"    delta="−6d" up />
        <KPI label="Ticket médio"      value="R$ 186k" delta="+12%" up />
      </div>
      <div className="card">
        <div className="card-hd"><h3>Performance por vendedor</h3></div>
        <div className="card-bd">
          <table className="tbl">
            <thead><tr><th>Vendedor</th><th>Negócios</th><th>Ganho</th><th>Win rate</th><th>Pipeline</th><th>Meta</th></tr></thead>
            <tbody>
              {OWNERS.map((o,i) => (
                <tr key={o.id}>
                  <td><div className="row"><Avatar owner={o} size="xs"/><strong>{o.name}</strong></div></td>
                  <td className="num">{[28,22,19,16,12][i]}</td>
                  <td className="num">{["R$ 720k","R$ 540k","R$ 410k","R$ 320k","R$ 240k"][i]}</td>
                  <td className="num">{["34%","29%","26%","22%","18%"][i]}</td>
                  <td className="num">{["R$ 1,4M","R$ 1,1M","R$ 890k","R$ 720k","R$ 520k"][i]}</td>
                  <td>
                    <div style={{width:120, height:6, background:"var(--c-panel-2)", borderRadius:3, overflow:"hidden"}}>
                      <div style={{width:[92, 80, 68, 54, 42][i]+"%", height:"100%", background:"var(--c-accent)"}}/>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
