function Dashboard() {
  const Icon = Icons;
  const hot = LEADS.filter(l => l.score >= 75).sort((a,b) => b.value - a.value).slice(0, 5);
  const stale = LEADS.filter(l => l.nextStep.state === "overdue");

  return (
    <div className="page-pad">
      <div className="page-head">
        <div>
          <div style={{ fontSize: 11, color: "var(--c-ink-3)", letterSpacing: ".06em", textTransform: "uppercase", marginBottom: 6 }}>
            Segunda, 20 de abril
          </div>
          <h1>Bom dia, Vitória.</h1>
          <div className="sub">Seu time está <strong style={{color:"var(--c-good)"}}>+12%</strong> acima da meta do trimestre. 4 negócios exigem sua atenção hoje.</div>
        </div>
        <div className="row" style={{gap:8}}>
          <button className="btn"><Icon.calendar size={13} /> Abr 2026</button>
          <button className="btn"><Icon.filter size={13} /> Todos os times</button>
        </div>
      </div>

      <div className="kpi-row">
        <KPI label="Pipeline aberto"  value="R$ 6,14M"  delta="+18,2%" up spark={[3,4,5,4,6,7,8,9,8,10,11,12]} />
        <KPI label="Fechado no mês"   value="R$ 1,28M"  delta="+24%"   up spark={[2,2,3,4,4,5,7,8,8,9,11,13]} />
        <KPI label="Meta trimestral"  value="76%"       delta="R$ 3,8M / 5M" subtle />
        <KPI label="Tempo médio p/ fechar" value="42 d" delta="−6 d"   up spark={[12,11,11,10,10,9,9,8,8,8,7,7]} />
      </div>

      <div className="grid-2" style={{ marginBottom: 14 }}>
        <div className="card">
          <div className="card-hd">
            <h3>Funil de conversão</h3>
            <span className="sub">· últimos 90 dias</span>
            <div style={{marginLeft:"auto"}} className="row">
              <span className="chip">Inbound</span>
              <span className="chip accent"><span className="dot"/> Todos</span>
            </div>
          </div>
          <div className="card-bd">
            <div className="funnel">
              {FUNNEL.map((f, i) => {
                const pct = (f.count / FUNNEL[0].count) * 100;
                return (
                  <div key={f.stage} className="funnel-row">
                    <span className="name"><span className="dot" style={{ width:8,height:8,borderRadius:"50%",background:`var(--st-${i+1})` }} />{f.stage}</span>
                    <div className="bar"><div className="fill" style={{ width: pct + "%" }} /></div>
                    <span className="count mono">{f.count}</span>
                    <span className="rate mono">{f.rate}%</span>
                  </div>
                );
              })}
            </div>
            <div className="divider" />
            <div className="row between" style={{fontSize:12, color:"var(--c-ink-3)"}}>
              <span>Valor total no funil <strong className="mono" style={{color:"var(--c-ink)"}}>R$ 7,77M</strong></span>
              <span>Taxa geral Novo → Ganho <strong className="mono" style={{color:"var(--c-ink)"}}>5,6%</strong></span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-hd">
            <h3>Atividade da equipe</h3>
            <span className="sub">· em tempo real</span>
            <span className="chip good" style={{marginLeft:"auto"}}><span className="dot"/>Ao vivo</span>
          </div>
          <div className="card-bd" style={{paddingTop:4, paddingBottom:4}}>
            <div className="feed">
              {ACTIVITIES.slice(0, 7).map(a => (
                <div key={a.id} className="feed-item">
                  <div className={"ic " + a.type}>
                    {a.type === "email" && <Icon.mail size={13} />}
                    {a.type === "call"  && <Icon.phone size={13} />}
                    {a.type === "whats" && <Icon.message size={13} />}
                    {a.type === "meet"  && <Icon.calendar size={13} />}
                    {a.type === "note"  && <Icon.flame size={13} />}
                    {a.type === "stage" && <Icon.trending size={13} />}
                  </div>
                  <div>
                    <div><strong>{a.who}</strong> <span className="dim">{a.what}</span></div>
                    <div className="meta">{a.lead}</div>
                  </div>
                  <div className="when">{a.when}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-hd">
            <h3>Negócios quentes</h3>
            <span className="sub">· score ≥ 75 · ordenado por valor</span>
            <button className="btn sm ghost" style={{marginLeft:"auto"}}>Ver todos <Icon.chevronRight size={12} /></button>
          </div>
          <div className="card-bd" style={{paddingTop: 4}}>
            {hot.map(l => {
              const owner = OWNERS.find(o => o.id === l.owner);
              return (
                <div key={l.id} className="row" style={{ padding: "10px 0", borderBottom: "1px dashed var(--c-line)" }}>
                  <CompanyMark logo={l.logo} size={28} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{l.company}</div>
                    <div style={{ fontSize: 11.5, color: "var(--c-ink-3)" }}>
                      <StageChip stageId={l.stage} /> · {l.contact}
                    </div>
                  </div>
                  <ScoreBar score={l.score} />
                  <div className="mono" style={{ width: 84, textAlign: "right", fontSize: 13 }}>{fmtBRL(l.value)}</div>
                  <Avatar owner={owner} size="xs" />
                </div>
              );
            })}
          </div>
        </div>

        <div className="card">
          <div className="card-hd">
            <h3 style={{display:"flex",alignItems:"center",gap:6}}>
              <Icon.sparkle size={13} style={{color:"var(--c-accent)"}} /> Atenção do gerente
            </h3>
            <span className="sub">· ações sugeridas pela IA</span>
          </div>
          <div className="card-bd" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <AlertRow tone="bad" title={`${stale.length} leads sem contato há mais de 5 dias`}
                     body="Risco de esfriamento — revisar com Rafael e Camila na 1:1 de terça." cta="Abrir lista" />
            <AlertRow tone="warn" title="Helena Farma · proposta aberta 7×"
                     body="Alto interesse de Beatriz Lima. Sugestão: ligação de fechamento esta semana." cta="Agendar call" />
            <AlertRow tone="info" title="Hórus Energia movida para Reunião há 12 dias"
                     body="Ciclo médio do estágio é 6 dias. Confirmar agenda com Thiago Brandão." cta="Rever atividade" />
            <AlertRow tone="good" title="Coral Têxtil fechado ontem · R$ 145k"
                     body="Enviar kickoff e atualizar forecast do trimestre." cta="Ver negócio" />
          </div>
        </div>
      </div>
    </div>
  );
}

function KPI({ label, value, delta, up, subtle, spark }) {
  return (
    <div className="kpi">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      <div className="foot">
        {!subtle && <span className={"delta " + (up ? "up" : "down")}>{delta}</span>}
        {subtle && <span className="delta">{delta}</span>}
        {!subtle && <span>vs. mês anterior</span>}
      </div>
      {spark && <Sparkline points={spark} />}
    </div>
  );
}

function AlertRow({ tone, title, body, cta }) {
  return (
    <div style={{
      padding: "11px 12px",
      borderRadius: 8,
      border: "1px solid var(--c-line)",
      display: "grid",
      gridTemplateColumns: "6px 1fr auto",
      gap: 12,
      alignItems: "center",
    }}>
      <span style={{
        height: "100%", borderRadius: 3,
        background: tone === "bad" ? "var(--c-bad)" : tone === "warn" ? "var(--c-warn)" : tone === "good" ? "var(--c-good)" : "var(--c-info)"
      }} />
      <div>
        <div style={{ fontSize: 12.5, fontWeight: 500 }}>{title}</div>
        <div style={{ fontSize: 11.5, color: "var(--c-ink-3)" }}>{body}</div>
      </div>
      <button className="btn sm">{cta}</button>
    </div>
  );
}

Object.assign(window, { Dashboard });
