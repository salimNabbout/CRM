function LeadsTable({ leads, onOpen }) {
  const [sel, setSel] = React.useState(new Set());
  const [sortBy, setSortBy] = React.useState("value");
  const [desc, setDesc] = React.useState(true);

  const sorted = React.useMemo(() => {
    const arr = [...leads];
    arr.sort((a,b) => {
      const av = a[sortBy], bv = b[sortBy];
      if (typeof av === "number") return desc ? bv - av : av - bv;
      return desc ? String(bv).localeCompare(String(av)) : String(av).localeCompare(String(bv));
    });
    return arr;
  }, [leads, sortBy, desc]);

  const toggle = (id) => { const n = new Set(sel); n.has(id) ? n.delete(id) : n.add(id); setSel(n); };
  const toggleAll = () => { if (sel.size === leads.length) setSel(new Set()); else setSel(new Set(leads.map(l => l.id))); };

  return (
    <div className="page">
      <div className="filters-bar">
        <span className="filter-pill"><Icons.filter size={12} /> Filtros (3)</span>
        <span className="filter-pill">Segmento: Tecnologia, Fintech <Icons.x size={11} className="x" /></span>
        <span className="filter-pill">Owner: Mariana Rocha <Icons.x size={11} className="x" /></span>
        <span className="filter-pill">Criado: últimos 30 dias <Icons.x size={11} className="x" /></span>
        <span className="filter-pill add"><Icons.plus size={11} /> Adicionar filtro</span>
        {sel.size > 0 ? (
          <div className="row" style={{marginLeft:"auto", gap:6}}>
            <span style={{fontSize:12, color:"var(--c-ink-3)"}}>{sel.size} selecionados</span>
            <button className="btn sm"><Icons.mail size={12} /> E-mail em lote</button>
            <button className="btn sm"><Icons.bolt size={12} /> Adicionar à cadência</button>
            <button className="btn sm">Atribuir owner</button>
          </div>
        ) : (
          <span style={{marginLeft:"auto", fontSize:12, color:"var(--c-ink-3)"}}>{leads.length} leads</span>
        )}
      </div>
      <table className="tbl">
        <thead>
          <tr>
            <th className="checkbox-col"><Checkbox checked={sel.size === leads.length} onChange={toggleAll} /></th>
            <th onClick={() => { setSortBy("company"); setDesc(!desc); }}>Empresa ↕</th>
            <th>Contato</th>
            <th>Segmento</th>
            <th>Cidade</th>
            <th>Estágio</th>
            <th onClick={() => { setSortBy("value"); setDesc(!desc); }}>Valor ↕</th>
            <th onClick={() => { setSortBy("score"); setDesc(!desc); }}>Score ↕</th>
            <th>Origem</th>
            <th>Owner</th>
            <th>Última interação</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map(l => {
            const owner = OWNERS.find(o => o.id === l.owner);
            return (
              <tr key={l.id} className={sel.has(l.id) ? "selected" : ""} onClick={() => onOpen(l.id)}>
                <td><Checkbox checked={sel.has(l.id)} onChange={() => toggle(l.id)} /></td>
                <td>
                  <div className="co-cell">
                    <CompanyMark logo={l.logo} />
                    <strong>{l.company}</strong>
                  </div>
                </td>
                <td>{l.contact}<div style={{fontSize:11,color:"var(--c-ink-3)"}}>{l.role}</div></td>
                <td className="dim">{l.segment}</td>
                <td className="dim">{l.city}</td>
                <td><StageChip stageId={l.stage} /></td>
                <td className="num">{fmtBRL(l.value)}</td>
                <td><ScoreBar score={l.score} /></td>
                <td><span className="tag">{l.source}</span></td>
                <td><div className="row" style={{gap:6}}><Avatar owner={owner} size="xs" /><span style={{fontSize:11.5}}>{owner.name.split(" ")[0]}</span></div></td>
                <td className="dim mono" style={{fontSize:11.5}}>{l.lastTouch}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

Object.assign(window, { LeadsTable });
