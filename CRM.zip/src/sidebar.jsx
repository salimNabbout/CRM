function Sidebar({ page, onNav }) {
  const Icon = Icons;
  const nav = [
    { id: "dashboard",   name: "Visão geral",       icon: Icon.dashboard },
    { id: "pipeline",    name: "Pipeline",          icon: Icon.kanban, count: 28 },
    { id: "leads",       name: "Leads",             icon: Icon.users, count: 312 },
    { id: "prospect",    name: "Prospecção",        icon: Icon.target, count: 46, badge: "IA" },
    { id: "inbox",       name: "Caixa de entrada",  icon: Icon.inbox, count: 9 },
    { id: "sequences",   name: "Cadências",         icon: Icon.bolt },
    { id: "reports",     name: "Relatórios",        icon: Icon.reports },
  ];
  const lists = [
    { id: "my",        name: "Minhas negociações",   count: 14 },
    { id: "closing",   name: "Fechando este mês",    count: 7 },
    { id: "atrasado",  name: "Sem contato 7+ dias",  count: 11, hot: true },
    { id: "enterprise",name: "Enterprise (ACV > 200k)", count: 9 },
  ];

  return (
    <aside className="sidebar">
      <div className="side-head">
        <div className="logo">C</div>
        <div className="logo-label">
          <strong>CETEM CRM</strong>
          <span>Prospecção & Leads</span>
        </div>
      </div>

      <div className="side-search">
        <div className="search-input">
          <Icon.search size={13} />
          <span>Buscar…</span>
          <kbd>⌘K</kbd>
        </div>
      </div>

      <nav className="side-nav">
        <div className="side-section">
          {nav.map(n => (
            <div key={n.id}
                 className={"nav-item" + (page === n.id ? " active" : "")}
                 onClick={() => onNav(n.id)}>
              <n.icon />
              <span>{n.name}</span>
              {n.badge && <span className="chip accent" style={{ height: 16, padding: "0 5px", fontSize: 9.5 }}>{n.badge}</span>}
              {n.count != null && <span className="count">{n.count}</span>}
            </div>
          ))}
        </div>

        <div className="side-section">
          <div className="side-section-title">Visualizações salvas</div>
          {lists.map(l => (
            <div key={l.id} className="nav-item" style={{ fontSize: 12.5 }}>
              <span style={{ width: 6, height: 6, borderRadius: 3, background: l.hot ? "var(--c-bad)" : "var(--c-ink-5)" }} />
              <span>{l.name}</span>
              <span className="count">{l.count}</span>
            </div>
          ))}
        </div>

        <div className="side-section">
          <div className="side-section-title">Equipe</div>
          {OWNERS.map(o => (
            <div key={o.id} className="nav-item" style={{ fontSize: 12.5 }}>
              <Avatar owner={o} size="xs" />
              <span>{o.name.split(" ")[0]} {o.name.split(" ")[1][0]}.</span>
              <span className="count">{[14,11,9,8,6][OWNERS.indexOf(o)]}</span>
            </div>
          ))}
        </div>
      </nav>

      <div className="side-foot">
        <Avatar owner={{ initials: "VS", hue: 200 }} size="sm" />
        <div className="who">
          <strong>Vitória Sardinha</strong>
          <span>Gerente Comercial</span>
        </div>
        <Icon.settings className="icon" size={14} style={{ color: "var(--c-ink-4)" }} />
      </div>
    </aside>
  );
}

Object.assign(window, { Sidebar });
