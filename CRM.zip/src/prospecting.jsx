function Prospecting() {
  const [selected, setSelected] = React.useState("p1");
  const p = PROSPECTS.find(x => x.id === selected);

  return (
    <div className="prospect">
      <div className="pros-list">
        <div className="pros-list-hd">
          <Icons.target size={14} style={{color:"var(--c-accent)"}} />
          <strong style={{fontSize:12.5}}>Prospecção inteligente</strong>
          <span className="chip accent" style={{marginLeft:"auto"}}>46 novos</span>
        </div>
        <div style={{padding: "8px 10px", borderBottom: "1px solid var(--c-line)", display: "flex", gap: 6, flexWrap:"wrap"}}>
          <span className="filter-pill" style={{fontSize:11}}>ICP: Tecnologia · Agro · Logística <Icons.x size={10} className="x"/></span>
          <span className="filter-pill" style={{fontSize:11}}>Porte: 100–1000 func. <Icons.x size={10} className="x"/></span>
          <span className="filter-pill add" style={{fontSize:11}}><Icons.plus size={10}/> Filtro</span>
        </div>
        <div className="pros-list-bd">
          {PROSPECTS.map(pr => (
            <div key={pr.id} className={"pros-item" + (pr.id === selected ? " active" : "")}
                 onClick={() => setSelected(pr.id)}>
              <CompanyMark logo={pr.company.split(" ").map(w=>w[0]).slice(0,2).join("")} size={28} />
              <div style={{flex:1, minWidth:0}}>
                <div className="nm">{pr.company}</div>
                <div className="dom mono">{pr.domain} · {pr.city}</div>
              </div>
              <span className={"fit " + (pr.fit === "Alto" ? "hi" : pr.fit === "Médio" ? "md" : "")}>
                {pr.score}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="pros-detail">
        <div className="pros-hero">
          <div className="pros-logo" style={{width:60, height:60, fontSize:18}}>
            {p.company.split(" ").map(w => w[0]).slice(0,2).join("")}
          </div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:11, color:"var(--c-ink-3)", textTransform:"uppercase", letterSpacing:".06em", marginBottom:2}}>Empresa-alvo · {p.fit.toUpperCase()} fit</div>
            <h2 style={{margin:"0 0 4px", fontFamily:"var(--font-serif)", fontSize: 30, fontWeight: 400, letterSpacing:"-0.01em", lineHeight: 1}}>{p.company}</h2>
            <div className="dim" style={{fontSize:13}}>{p.segment} · {p.city}</div>
            <div className="row" style={{gap:6, marginTop:10}}>
              <span className="chip"><Icons.link size={10}/> {p.domain}</span>
              <span className="chip accent"><Icons.flame size={10}/> Score {p.score}</span>
              <span className="chip">B2B Enterprise</span>
            </div>
          </div>
          <div className="row" style={{gap:6}}>
            <button className="btn">Descartar</button>
            <button className="btn primary"><Icons.plus size={13} /> Adicionar ao pipeline</button>
          </div>
        </div>

        <div style={{padding:"20px 24px"}}>
          <div className="ai-card" style={{marginBottom: 18}}>
            <div className="hd"><Icons.sparkle size={12} /> Por que prospectar esta empresa?</div>
            <div style={{color:"var(--c-accent-ink)", marginBottom: 8}}>
              Match forte com o ICP de Tecnologia & Energia. 3 sinais recentes indicam alta intenção e orçamento em aberto.
            </div>
            <ul style={{margin:0, paddingLeft:18, fontSize:12.5, color:"var(--c-accent-ink)", lineHeight: 1.6}}>
              {p.signals.map((s,i) => <li key={i}>{s}</li>)}
            </ul>
          </div>

          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginBottom: 22}}>
            <div>
              <h4 style={{margin:"0 0 10px", fontSize:12, textTransform:"uppercase", letterSpacing:".06em", color:"var(--c-ink-4)"}}>Contatos identificados</h4>
              <div style={{display:"flex", flexDirection:"column", gap:8}}>
                {p.contacts.map((c,i) => (
                  <div key={i} style={{padding:"11px 12px", border:"1px solid var(--c-line)", borderRadius:8, background:"var(--c-panel-2)"}}>
                    <div className="row">
                      <Avatar owner={{ initials: c.name.split(" ").map(x=>x[0]).slice(0,2).join(""), hue: 40 + i*80 }} size="sm" />
                      <div style={{flex:1}}>
                        <div style={{fontSize:12.5, fontWeight:500}}>
                          {c.name} {c.isKey && <span className="chip accent" style={{fontSize:10, marginLeft:4}}>Decisor</span>}
                        </div>
                        <div style={{fontSize:11.5, color:"var(--c-ink-3)"}}>{c.role}</div>
                      </div>
                    </div>
                    <div className="mono" style={{fontSize:11, color:"var(--c-ink-3)", marginTop:6}}>
                      {c.email}{c.phone && " · "+c.phone}
                    </div>
                  </div>
                ))}
                <button className="btn sm" style={{alignSelf:"flex-start"}}><Icons.plus size={12}/> Enriquecer mais contatos</button>
              </div>
            </div>

            <div>
              <h4 style={{margin:"0 0 10px", fontSize:12, textTransform:"uppercase", letterSpacing:".06em", color:"var(--c-ink-4)"}}>Cadência sugerida</h4>
              <div style={{border:"1px solid var(--c-line)", borderRadius:8, overflow:"hidden"}}>
                {[
                  { d: "Dia 1", k: "E-mail", t: "Abertura · referência a rodada série B" },
                  { d: "Dia 3", k: "LinkedIn", t: "Connect request personalizado" },
                  { d: "Dia 5", k: "Ligação", t: "Primeira tentativa — script ERP" },
                  { d: "Dia 8", k: "E-mail", t: "Case Hórus Energia · payback 9m" },
                  { d: "Dia 12", k: "WhatsApp", t: "Nudge + convite para demo de 20 min" },
                ].map((s,i) => (
                  <div key={i} style={{
                    padding:"10px 12px",
                    borderBottom: i < 4 ? "1px solid var(--c-line)" : "none",
                    display:"grid", gridTemplateColumns:"46px 60px 1fr", gap:10, alignItems:"center",
                    background:"var(--c-panel)", fontSize:12
                  }}>
                    <span className="mono dim-2">{s.d}</span>
                    <span className="tag">{s.k}</span>
                    <span>{s.t}</span>
                  </div>
                ))}
              </div>
              <button className="btn sm primary" style={{marginTop:10, width:"100%"}}>
                <Icons.bolt size={12}/> Iniciar cadência
              </button>
            </div>
          </div>

          <div>
            <h4 style={{margin:"0 0 10px", fontSize:12, textTransform:"uppercase", letterSpacing:".06em", color:"var(--c-ink-4)"}}>Sinais de monitoramento</h4>
            <div style={{display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:10}}>
              {[
                { l: "Funcionários", v: "+8%", s: "últimos 90 dias", up: true },
                { l: "Vagas em TI",   v: "4",   s: "abertas agora", up: true },
                { l: "Tráfego site",  v: "+22%",s: "mês vs. mês",   up: true },
                { l: "Menções",       v: "17",  s: "último mês",    up: false },
              ].map((k,i) => (
                <div key={i} className="mini-kpi">
                  <div className="label">{k.l}</div>
                  <div className="value">{k.v}</div>
                  <div className="foot">{k.s}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Prospecting });
