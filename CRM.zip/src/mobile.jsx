function MobileView() {
  const [tab, setTab] = React.useState("pipeline");
  const hot = LEADS.filter(l => l.score >= 70).slice(0, 6);

  return (
    <div className="mobile-shell">
      <div className="phone">
        <div className="notch" />
        <div className="phone-status">
          <span>9:41</span>
          <span className="mono" style={{fontSize:10}}>CETEM CRM</span>
          <span>●●● 100%</span>
        </div>
        <div className="phone-body">
          {tab === "home" && (
            <>
              <div style={{padding:"8px 0 12px"}}>
                <div style={{fontSize:11, color:"var(--c-ink-3)", textTransform:"uppercase", letterSpacing:".06em"}}>Seg, 20 abr</div>
                <h2 style={{margin:"2px 0 0", fontFamily:"var(--font-serif)", fontSize:26, fontWeight:400}}>Olá, Vitória.</h2>
              </div>
              <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:10}}>
                <div className="mini-kpi"><div className="label">Pipeline</div><div className="value">R$ 6,1M</div><div className="foot" style={{color:"var(--c-good)"}}>+18%</div></div>
                <div className="mini-kpi"><div className="label">Mês</div><div className="value">R$ 1,28M</div><div className="foot" style={{color:"var(--c-good)"}}>+24%</div></div>
                <div className="mini-kpi"><div className="label">Meta Q2</div><div className="value">76%</div><div className="foot">R$ 3,8M</div></div>
                <div className="mini-kpi"><div className="label">Ações hoje</div><div className="value">11</div><div className="foot" style={{color:"var(--c-bad)"}}>3 atrasadas</div></div>
              </div>
              <div style={{fontSize:11, color:"var(--c-ink-4)", textTransform:"uppercase", letterSpacing:".06em", margin:"14px 0 8px"}}>Hoje</div>
              {LEADS.filter(l => l.nextStep.state === "today" || l.nextStep.state === "overdue").slice(0,4).map(l => (
                <div key={l.id} className="m-card">
                  <div className="row" style={{marginBottom:4}}>
                    <CompanyMark logo={l.logo} />
                    <strong style={{fontSize:12.5, flex:1}}>{l.company}</strong>
                    <span className="mono" style={{fontSize:11.5}}>{fmtBRL(l.value)}</span>
                  </div>
                  <div className={"next-step " + (l.nextStep.state || "")} style={{margin:"4px 0 0"}}>
                    <Icons.clock /> <span style={{flex:1}}>{l.nextStep.label}</span>
                    <span className="mono" style={{fontSize:10.5}}>{l.nextStep.due}</span>
                  </div>
                </div>
              ))}
            </>
          )}
          {tab === "pipeline" && (
            <>
              <div style={{padding:"8px 0 12px"}}>
                <h2 style={{margin:"2px 0 0", fontFamily:"var(--font-serif)", fontSize:24, fontWeight:400}}>Pipeline</h2>
                <div style={{fontSize:12, color:"var(--c-ink-3)"}}>{LEADS.length} negócios · R$ 6,14M</div>
              </div>
              <div style={{display:"flex", gap:6, overflowX:"auto", paddingBottom:8, marginBottom:8}}>
                {STAGES.map(s => {
                  const ct = LEADS.filter(l => l.stage === s.id).length;
                  return <span key={s.id} className="chip" style={{flexShrink:0}}>
                    <span className="dot" style={{background:s.color}}/>{s.name.split(" ")[0]} <span className="mono dim-2" style={{fontSize:10}}>{ct}</span>
                  </span>;
                })}
              </div>
              {hot.map(l => {
                const owner = OWNERS.find(o => o.id === l.owner);
                return (
                  <div key={l.id} className="m-card">
                    <div className="row" style={{marginBottom:6}}>
                      <CompanyMark logo={l.logo} />
                      <div style={{flex:1, minWidth:0}}>
                        <div style={{fontSize:13, fontWeight:500}}>{l.company}</div>
                        <div style={{fontSize:11, color:"var(--c-ink-3)"}}>{l.contact}</div>
                      </div>
                      <Avatar owner={owner} size="xs" />
                    </div>
                    <div className="row" style={{fontSize:11}}>
                      <StageChip stageId={l.stage} />
                      <span className="mono" style={{marginLeft:"auto", color:"var(--c-ink)", fontWeight:500}}>{fmtBRL(l.value)}</span>
                    </div>
                  </div>
                );
              })}
            </>
          )}
          {tab === "prospect" && (
            <>
              <div style={{padding:"8px 0 12px"}}>
                <h2 style={{margin:"2px 0 0", fontFamily:"var(--font-serif)", fontSize:24, fontWeight:400}}>Prospecção</h2>
                <div style={{fontSize:12, color:"var(--c-ink-3)"}}>46 empresas sugeridas pela IA</div>
              </div>
              {PROSPECTS.slice(0,5).map(p => (
                <div key={p.id} className="m-card">
                  <div className="row" style={{marginBottom:4}}>
                    <CompanyMark logo={p.company.split(" ").map(w=>w[0]).slice(0,2).join("")} />
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{fontSize:12.5, fontWeight:500}}>{p.company}</div>
                      <div className="mono" style={{fontSize:11, color:"var(--c-ink-3)"}}>{p.domain}</div>
                    </div>
                    <span className={"fit " + (p.fit === "Alto" ? "hi" : p.fit === "Médio" ? "md" : "")} style={{
                      padding:"2px 6px", borderRadius:4, fontSize:11, fontFamily:"var(--font-mono)"
                    }}>{p.score}</span>
                  </div>
                  <div style={{fontSize:11.5, color:"var(--c-ink-3)"}}>{p.signals[0]}</div>
                </div>
              ))}
            </>
          )}
          {tab === "inbox" && (
            <>
              <div style={{padding:"8px 0 12px"}}>
                <h2 style={{margin:"2px 0 0", fontFamily:"var(--font-serif)", fontSize:24, fontWeight:400}}>Caixa de entrada</h2>
              </div>
              {ACTIVITIES.slice(0,7).map(a => (
                <div key={a.id} className="m-card">
                  <div className="row" style={{marginBottom:4}}>
                    <div className={"ic " + a.type} style={{width:24, height:24, borderRadius:6, display:"grid", placeItems:"center"}}>
                      {a.type === "email" && <Icons.mail size={12}/>}
                      {a.type === "call" && <Icons.phone size={12}/>}
                      {a.type === "whats" && <Icons.message size={12}/>}
                      {a.type === "meet" && <Icons.calendar size={12}/>}
                      {a.type === "note" && <Icons.flame size={12}/>}
                      {a.type === "stage" && <Icons.trending size={12}/>}
                    </div>
                    <strong style={{fontSize:12.5, flex:1}}>{a.lead}</strong>
                    <span className="mono dim-2" style={{fontSize:10}}>{a.when}</span>
                  </div>
                  <div style={{fontSize:12, color:"var(--c-ink-2)"}}>{a.who} {a.what}</div>
                </div>
              ))}
            </>
          )}
        </div>
        <div className="phone-tabbar">
          <button className={tab === "home" ? "active" : ""} onClick={() => setTab("home")}><Icons.home /> Hoje</button>
          <button className={tab === "pipeline" ? "active" : ""} onClick={() => setTab("pipeline")}><Icons.kanban /> Pipeline</button>
          <button className={tab === "prospect" ? "active" : ""} onClick={() => setTab("prospect")}><Icons.target /> Prospecção</button>
          <button className={tab === "inbox" ? "active" : ""} onClick={() => setTab("inbox")}><Icons.inbox /> Inbox</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MobileView });
