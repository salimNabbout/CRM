function TweaksPanel({ tweaks, setTweak, onClose }) {
  const accents = [
    { id: "emerald", color: "oklch(62% 0.13 160)" },
    { id: "indigo",  color: "oklch(55% 0.17 275)" },
    { id: "amber",   color: "oklch(70% 0.14 75)" },
    { id: "rose",    color: "oklch(62% 0.17 10)" },
  ];
  const Row = ({ label, children }) => (
    <div className="tweak-row">
      <div className="label">{label}</div>
      {children}
    </div>
  );
  const Opt = ({ k, v, children }) => (
    <button className={tweaks[k] === v ? "active" : ""} onClick={() => setTweak(k, v)}>{children}</button>
  );
  return (
    <div className="tweaks-panel">
      <div className="tweaks-hd">
        <Icons.sparkle size={13} style={{color:"var(--c-accent)"}}/>
        <strong>Tweaks</strong>
        <button className="btn ghost icon-only sm" onClick={onClose}><Icons.x size={12}/></button>
      </div>
      <div className="tweaks-bd">
        <Row label="Dispositivo">
          <div className="tweak-opts">
            <Opt k="device" v="desktop">Desktop</Opt>
            <Opt k="device" v="mobile">Mobile</Opt>
          </div>
        </Row>
        <Row label="Tema">
          <div className="tweak-opts">
            <Opt k="theme" v="light">Claro</Opt>
            <Opt k="theme" v="dark">Escuro</Opt>
          </div>
        </Row>
        <Row label="Acento">
          <div className="swatches">
            {accents.map(a => (
              <div key={a.id}
                   className={"swatch" + (tweaks.accent === a.id ? " active" : "")}
                   style={{ background: a.color }}
                   onClick={() => setTweak("accent", a.id)} />
            ))}
          </div>
        </Row>
        <Row label="Densidade">
          <div className="tweak-opts">
            <Opt k="density" v="spacious">Espaçoso</Opt>
            <Opt k="density" v="balanced">Balanceado</Opt>
            <Opt k="density" v="dense">Denso</Opt>
          </div>
        </Row>
        <Row label="Visualização do pipeline">
          <div className="tweak-opts">
            <Opt k="pipelineView" v="kanban">Kanban</Opt>
            <Opt k="pipelineView" v="list">Lista</Opt>
            <Opt k="pipelineView" v="forecast">Forecast</Opt>
          </div>
        </Row>
        <Row label="Detalhe do lead">
          <div className="tweak-opts">
            <Opt k="leadDetail" v="drawer">Drawer lateral</Opt>
            <Opt k="leadDetail" v="modal">Modal central</Opt>
          </div>
        </Row>
        <Row label="Sugestões de IA">
          <div className="tweak-opts">
            <Opt k="showAIHints" v={true}>Ligadas</Opt>
            <Opt k="showAIHints" v={false}>Desligadas</Opt>
          </div>
        </Row>
      </div>
    </div>
  );
}

Object.assign(window, { TweaksPanel });
