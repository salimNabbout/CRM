// ---------- Sample data ---------- //
// Fictional B2B SaaS / tech-services prospects for CETEM Tecnologia.

const STAGES = [
  { id: "novo",       name: "Novo lead",       color: "var(--st-1)", desc: "Capturado, sem contato" },
  { id: "qualif",     name: "Qualificação",    color: "var(--st-2)", desc: "Em descoberta" },
  { id: "reuniao",    name: "Reunião agendada", color: "var(--st-3)", desc: "Call booked" },
  { id: "proposta",   name: "Proposta",         color: "var(--st-4)", desc: "Enviada ao cliente" },
  { id: "negociacao", name: "Negociação",       color: "var(--st-5)", desc: "Discussão de termos" },
  { id: "ganho",      name: "Fechado — Ganho",  color: "var(--st-6)", desc: "Contrato assinado" },
];

const OWNERS = [
  { id: "mr", name: "Mariana Rocha",   initials: "MR", hue: 30 },
  { id: "bf", name: "Bruno Ferreira",  initials: "BF", hue: 220 },
  { id: "cs", name: "Camila Souza",    initials: "CS", hue: 320 },
  { id: "ro", name: "Rafael Oliveira", initials: "RO", hue: 150 },
  { id: "ja", name: "Juliana Alves",   initials: "JA", hue: 280 },
];

const TAGS = ["Inbound", "Outbound", "Indicação", "Evento", "ABM", "Retargeting"];

const LEADS = [
  {
    id: "L-1021", company: "Vortex Logística", logo: "VL", segment: "Transporte & Logística",
    contact: "Pedro Castanho", role: "CTO", email: "pedro@vortexlog.com.br", phone: "+55 11 99812-4401",
    city: "São Paulo, SP", employees: "210", revenue: "R$ 140M",
    stage: "negociacao", value: 185000, probability: 70, score: 86, owner: "mr",
    source: "Outbound", tag: "ABM",
    createdAt: "12 Mar 2026", lastTouch: "3h atrás",
    nextStep: { label: "Ligação com o diretor financeiro", due: "Hoje, 16h", state: "today" }
  },
  {
    id: "L-1033", company: "Helena Farma", logo: "HF", segment: "Saúde",
    contact: "Beatriz Lima", role: "Diretora de TI", email: "beatriz.lima@helenafarma.com", phone: "+55 21 98812-9900",
    city: "Rio de Janeiro, RJ", employees: "640", revenue: "R$ 420M",
    stage: "proposta", value: 320000, probability: 55, score: 78, owner: "bf",
    source: "Indicação", tag: "Inbound",
    createdAt: "02 Mar 2026", lastTouch: "ontem",
    nextStep: { label: "Revisar proposta técnica", due: "Amanhã, 10h", state: "" }
  },
  {
    id: "L-1047", company: "Cedro Agro", logo: "CA", segment: "Agronegócio",
    contact: "Rodrigo Pimenta", role: "COO", email: "rodrigo@cedroagro.com", phone: "+55 62 99410-1123",
    city: "Goiânia, GO", employees: "1.100", revenue: "R$ 820M",
    stage: "reuniao", value: 260000, probability: 40, score: 72, owner: "cs",
    source: "Evento", tag: "Evento",
    createdAt: "18 Mar 2026", lastTouch: "2 dias",
    nextStep: { label: "Demo técnica da plataforma", due: "Sex, 14h", state: "" }
  },
  {
    id: "L-1058", company: "Altura Construtora", logo: "AC", segment: "Construção Civil",
    contact: "Marcos Andrade", role: "Gerente de PMO", email: "m.andrade@altura.com.br", phone: "+55 11 98211-3300",
    city: "Campinas, SP", employees: "320", revenue: "R$ 210M",
    stage: "qualif", value: 95000, probability: 25, score: 58, owner: "ro",
    source: "Outbound", tag: "Outbound",
    createdAt: "22 Mar 2026", lastTouch: "5 dias",
    nextStep: { label: "Follow-up e-mail de descoberta", due: "Atrasado 2d", state: "overdue" }
  },
  {
    id: "L-1061", company: "Nimbus Cloud", logo: "NC", segment: "Tecnologia",
    contact: "Ana Prestes", role: "VP Engineering", email: "ana@nimbus.cloud", phone: "+55 11 97000-2211",
    city: "São Paulo, SP", employees: "85", revenue: "R$ 60M",
    stage: "novo", value: 75000, probability: 10, score: 64, owner: "ja",
    source: "Inbound", tag: "Inbound",
    createdAt: "30 Mar 2026", lastTouch: "1h atrás",
    nextStep: { label: "Primeiro contato — e-mail de abertura", due: "Hoje", state: "today" }
  },
  {
    id: "L-1072", company: "Rio Verde Bank", logo: "RV", segment: "Serviços Financeiros",
    contact: "Felipe Vasques", role: "Head of Data", email: "felipe.vasques@rioverde.bank", phone: "+55 11 99112-0099",
    city: "São Paulo, SP", employees: "2.400", revenue: "R$ 3,1B",
    stage: "negociacao", value: 540000, probability: 65, score: 92, owner: "mr",
    source: "ABM", tag: "ABM",
    createdAt: "08 Fev 2026", lastTouch: "hoje",
    nextStep: { label: "Mesa redonda com jurídico", due: "Ter, 09h", state: "" }
  },
  {
    id: "L-1080", company: "Plano Pagamentos", logo: "PP", segment: "Fintech",
    contact: "Cecília Moreira", role: "Product Lead", email: "ceci@planopag.com", phone: "+55 11 98823-4412",
    city: "Curitiba, PR", employees: "140", revenue: "R$ 90M",
    stage: "proposta", value: 210000, probability: 50, score: 74, owner: "bf",
    source: "Inbound", tag: "Inbound",
    createdAt: "14 Mar 2026", lastTouch: "ontem",
    nextStep: { label: "Apresentar SOW revisado", due: "Qui, 11h", state: "" }
  },
  {
    id: "L-1083", company: "Ôntica Visão", logo: "OV", segment: "Varejo",
    contact: "Lucas Tavares", role: "CEO", email: "lucas@onticavisao.com", phone: "+55 31 99801-5500",
    city: "Belo Horizonte, MG", employees: "440", revenue: "R$ 180M",
    stage: "qualif", value: 120000, probability: 20, score: 66, owner: "cs",
    source: "Outbound", tag: "Outbound",
    createdAt: "21 Mar 2026", lastTouch: "3 dias",
    nextStep: { label: "Agendar reunião de descoberta", due: "Qua, 15h", state: "" }
  },
  {
    id: "L-1089", company: "Praia Azul Turismo", logo: "PA", segment: "Turismo",
    contact: "Marta Nogueira", role: "Diretora Comercial", email: "marta@praiaazul.tur.br", phone: "+55 71 98422-9910",
    city: "Salvador, BA", employees: "95", revenue: "R$ 52M",
    stage: "novo", value: 48000, probability: 10, score: 54, owner: "ro",
    source: "Inbound", tag: "Retargeting",
    createdAt: "02 Abr 2026", lastTouch: "hoje",
    nextStep: { label: "Enviar one-pager do produto", due: "Hoje", state: "today" }
  },
  {
    id: "L-1092", company: "Hórus Energia", logo: "HE", segment: "Energia",
    contact: "Thiago Brandão", role: "Diretor de Operações", email: "thiago@horusenergia.com.br", phone: "+55 11 98400-3311",
    city: "São Paulo, SP", employees: "780", revenue: "R$ 640M",
    stage: "reuniao", value: 380000, probability: 45, score: 81, owner: "ja",
    source: "ABM", tag: "ABM",
    createdAt: "11 Mar 2026", lastTouch: "hoje",
    nextStep: { label: "Reunião de alinhamento técnico", due: "Hoje, 17h", state: "today" }
  },
  {
    id: "L-1094", company: "Coral Têxtil", logo: "CT", segment: "Indústria",
    contact: "Sandra Iglesias", role: "CIO", email: "sandra.iglesias@coraltextil.com.br", phone: "+55 47 98222-7788",
    city: "Blumenau, SC", employees: "320", revenue: "R$ 195M",
    stage: "ganho", value: 145000, probability: 100, score: 88, owner: "mr",
    source: "Indicação", tag: "Indicação",
    createdAt: "10 Jan 2026", lastTouch: "semana passada",
    nextStep: { label: "Kickoff de implantação", due: "Seg, 10h", state: "" }
  },
  {
    id: "L-1098", company: "Savana Edu", logo: "SE", segment: "Educação",
    contact: "Diego Saldanha", role: "Head of IT", email: "diego@savanaedu.com", phone: "+55 51 99111-4422",
    city: "Porto Alegre, RS", employees: "180", revenue: "R$ 75M",
    stage: "negociacao", value: 98000, probability: 55, score: 70, owner: "bf",
    source: "Outbound", tag: "Outbound",
    createdAt: "26 Fev 2026", lastTouch: "2 dias",
    nextStep: { label: "Ajustar condições comerciais", due: "Qua, 14h", state: "" }
  },
  {
    id: "L-1101", company: "Móveis Laguna", logo: "ML", segment: "Varejo",
    contact: "Paulo Régio", role: "CEO", email: "paulo@laguna.com.br", phone: "+55 11 99801-1122",
    city: "São Paulo, SP", employees: "60", revenue: "R$ 28M",
    stage: "qualif", value: 36000, probability: 15, score: 48, owner: "cs",
    source: "Inbound", tag: "Retargeting",
    createdAt: "28 Mar 2026", lastTouch: "4 dias",
    nextStep: { label: "Qualificar BANT", due: "Atrasado 1d", state: "overdue" }
  },
  {
    id: "L-1107", company: "Meridiano Seguros", logo: "MS", segment: "Seguros",
    contact: "Helena Ayres", role: "Gerente de Inovação", email: "helena@meridianoseguros.com", phone: "+55 21 99544-2200",
    city: "Rio de Janeiro, RJ", employees: "1.400", revenue: "R$ 2,4B",
    stage: "proposta", value: 460000, probability: 50, score: 85, owner: "ja",
    source: "Evento", tag: "Evento",
    createdAt: "05 Mar 2026", lastTouch: "hoje",
    nextStep: { label: "Workshop de escopo técnico", due: "Qui, 09h", state: "" }
  }
];

const ACTIVITIES = [
  { id: "a1", type: "email",  who: "Mariana Rocha",   lead: "Vortex Logística",  what: "enviou proposta comercial — v3",        when: "há 12 min" },
  { id: "a2", type: "call",   who: "Bruno Ferreira",  lead: "Helena Farma",      what: "ligação atendida · 14 min",             when: "há 38 min" },
  { id: "a3", type: "stage",  who: "Mariana Rocha",   lead: "Rio Verde Bank",    what: "moveu para Negociação",                 when: "há 1h" },
  { id: "a4", type: "whats",  who: "Camila Souza",    lead: "Cedro Agro",        what: "WhatsApp — confirmação de demo",        when: "há 2h" },
  { id: "a5", type: "meet",   who: "Juliana Alves",   lead: "Hórus Energia",     what: "reunião agendada · Qui 17h",            when: "há 3h" },
  { id: "a6", type: "note",   who: "Rafael Oliveira", lead: "Altura Construtora", what: "deal em risco — sem resposta 5 dias",  when: "há 4h" },
  { id: "a7", type: "email",  who: "Bruno Ferreira",  lead: "Plano Pagamentos",  what: "sequência de follow-up (2/4) enviada",   when: "há 6h" },
  { id: "a8", type: "call",   who: "Mariana Rocha",   lead: "Coral Têxtil",      what: "contrato assinado — R$ 145.000",        when: "ontem" },
];

const FUNNEL = [
  { stage: "Novo lead",        count: 124, value: 2400000, rate: 100 },
  { stage: "Qualificação",     count:  82, value: 1820000, rate: 66 },
  { stage: "Reunião agendada", count:  48, value: 1340000, rate: 58 },
  { stage: "Proposta",         count:  26, value:  980000, rate: 54 },
  { stage: "Negociação",       count:  14, value:  820000, rate: 54 },
  { stage: "Fechado — Ganho",  count:   7, value:  412000, rate: 50 },
];

const PROSPECTS = [
  { id: "p1", company: "Solaris Energia Renovável", domain: "solaris.com.br", segment: "Energia · 240 func.",   city: "Florianópolis, SC", fit: "Alto", score: 91,
    signals: ["Abertura de vagas em tecnologia (+4)", "Menção a ERP legado em blog", "Rodada série B em Mar/26"],
    contacts: [
      { name: "Renata Pacheco", role: "CTO", email: "renata@solaris.com.br", phone: "+55 48 99811-2200", isKey: true },
      { name: "Daniel Corrêa",  role: "Diretor Financeiro", email: "daniel@solaris.com.br" }
    ]},
  { id: "p2", company: "Pampas Nutrição Animal", domain: "pampasnut.com", segment: "Agronegócio · 480 func.", city: "Campo Grande, MS", fit: "Alto", score: 84,
    signals: ["Expansão para 2 novos estados", "Contratação de Head de TI", "Uso detectado: SAP + planilhas"],
    contacts: [
      { name: "João Batista",    role: "Head of IT", email: "joao@pampasnut.com", phone: "+55 67 99400-1120", isKey: true },
    ]},
  { id: "p3", company: "Orla Cosméticos", domain: "orlacosmeticos.com", segment: "Cosméticos · 160 func.", city: "Recife, PE", fit: "Médio", score: 68,
    signals: ["Reforma do e-commerce anunciada", "Queda de avaliação em app"],
    contacts: [
      { name: "Tatiana Melo", role: "CMO", email: "tatiana@orlacosmeticos.com" }
    ]},
  { id: "p4", company: "Grão Fino Alimentos", domain: "graofino.com.br", segment: "Alimentos · 720 func.", city: "Londrina, PR", fit: "Médio", score: 62,
    signals: ["Menção ao CETEM em evento", "3 contatos novos no LinkedIn"],
    contacts: [
      { name: "Elisa Toledo", role: "Diretora Industrial", email: "elisa@graofino.com.br" }
    ]},
  { id: "p5", company: "Atlas Móveis Corporativos", domain: "atlasmoveis.com", segment: "Indústria · 310 func.", city: "São José dos Pinhais, PR", fit: "Baixo", score: 44,
    signals: ["Segmento fora do ICP principal"],
    contacts: [
      { name: "Ronaldo Vieira", role: "CEO", email: "ronaldo@atlasmoveis.com" }
    ]},
  { id: "p6", company: "Porto Verde Shipping", domain: "portoverde.com", segment: "Logística · 540 func.", city: "Santos, SP", fit: "Alto", score: 88,
    signals: ["Licitação pública encerrada", "Contratação de Diretor de Transformação Digital"],
    contacts: [
      { name: "Mirela Assumpção", role: "Dir. Transf. Digital", email: "mirela@portoverde.com", isKey: true }
    ]},
];

const TIMELINE = [
  { type: "stage",  title: "Estágio alterado para Negociação",   by: "Mariana Rocha", when: "hoje · 14:22", body: "Moveu Vortex Logística de Proposta para Negociação após resposta positiva do Pedro." },
  { type: "email",  title: "E-mail enviado",                     by: "Mariana Rocha", when: "hoje · 14:10", body: "Assunto: Ajustes na proposta v3 — condições de pagamento e SLA. Aberto 2× em 12 min." },
  { type: "call",   title: "Ligação · 14 min",                   by: "Mariana Rocha", when: "ontem · 16:30", body: "Alinhado escopo do módulo de rastreamento. Pedro pediu revisão de SLA e prazo de implantação." },
  { type: "note",   title: "Nota interna",                       by: "Mariana Rocha", when: "ontem · 11:05", body: "CFO é bloqueador. Precisamos mostrar payback em 9 meses na próxima reunião." },
  { type: "meet",   title: "Reunião · 45 min",                   by: "Mariana Rocha", when: "20 Mar · 10:00", body: "Demo técnica com o time de operações. Feedback positivo em roteirização." },
  { type: "whats",  title: "WhatsApp",                           by: "Mariana Rocha", when: "15 Mar · 09:22", body: "Confirmação de presença do Pedro na demo. Enviou também contato da Gerente de Frota." },
  { type: "email",  title: "Sequência de follow-up · 2/4",       by: "Sistema",       when: "12 Mar · 08:00", body: "E-mail automático da cadência Outbound SP — Logística." },
];

Object.assign(window, {
  STAGES, OWNERS, TAGS, LEADS, ACTIVITIES, FUNNEL, PROSPECTS, TIMELINE
});
