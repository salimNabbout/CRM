// ---------- Tiny reusable primitives ---------- //

function Avatar({ owner, size = "sm" }) {
  if (!owner) return null;
  const sz = { xs: 18, sm: 22, md: 28, lg: 40 }[size] || 22;
  const bg = `linear-gradient(135deg, oklch(78% 0.10 ${owner.hue}), oklch(55% 0.14 ${(owner.hue + 60) % 360}))`;
  return (
    <div className={"avatar " + size} style={{ background: bg, width: sz, height: sz }} title={owner.name}>
      {owner.initials}
    </div>
  );
}

function CompanyMark({ logo, size = 22 }) {
  return (
    <div className="co-logo" style={{ width: size, height: size, fontSize: size * 0.44 }}>{logo}</div>
  );
}

function StageChip({ stageId, withDot = true }) {
  const stage = STAGES.find(s => s.id === stageId);
  if (!stage) return null;
  return (
    <span className="stage-chip">
      {withDot && <span className="dot" style={{ background: stage.color }} />}
      {stage.name}
    </span>
  );
}

function Sparkline({ points = [4,6,5,7,8,7,9,11,10,12,14,13], color = "currentColor", w = 92, h = 32 }) {
  const max = Math.max(...points), min = Math.min(...points);
  const range = max - min || 1;
  const step = w / (points.length - 1);
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${(i * step).toFixed(1)},${(h - ((p - min) / range) * (h - 4) - 2).toFixed(1)}`).join(" ");
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <path d={path} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function fmtBRL(n) {
  if (n >= 1000000) return "R$ " + (n / 1000000).toFixed(n >= 10000000 ? 1 : 2) + "M";
  if (n >= 1000) return "R$ " + (n / 1000).toFixed(0) + "k";
  return "R$ " + n;
}

function ScoreBar({ score }) {
  return (
    <span className="score" title={`Lead score: ${score}`}>
      <span className="score-bar"><span style={{ width: score + "%" }} /></span>
      <span>{score}</span>
    </span>
  );
}

function Checkbox({ checked, onChange }) {
  return (
    <span className={"checkbox" + (checked ? " checked" : "")}
          onClick={(e) => { e.stopPropagation(); onChange && onChange(!checked); }} />
  );
}

Object.assign(window, { Avatar, CompanyMark, StageChip, Sparkline, fmtBRL, ScoreBar, Checkbox });
