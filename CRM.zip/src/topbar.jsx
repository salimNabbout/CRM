function Topbar({ page, onTweaks, pipelineView, setPipelineView, onAddLead }) {
  const Icon = Icons;
  const labels = {
    dashboard: "Visão geral",
    pipeline: "Pipeline",
    leads: "Leads",
    prospect: "Prospecção",
    inbox: "Caixa de entrada",
    sequences: "Cadências",
    reports: "Relatórios",
  };
  return (
    <div className="topbar">
      <div className="crumbs">
        <span>CETEM</span>
        <span className="sep">/</span>
        <strong>{labels[page] || page}</strong>
        {page === "pipeline" && <>
          <span className="sep">/</span>
          <span>Q2 · 2026</span>
        </>}
      </div>
      <div className="spacer" />

      {page === "pipeline" && (
        <div className="view-tabs">
          <button className={pipelineView === "kanban" ? "active" : ""} onClick={() => setPipelineView("kanban")}>
            <Icon.kanban size={13} /> Kanban
          </button>
          <button className={pipelineView === "list" ? "active" : ""} onClick={() => setPipelineView("list")}>
            <Icon.list size={13} /> Lista
          </button>
          <button className={pipelineView === "forecast" ? "active" : ""} onClick={() => setPipelineView("forecast")}>
            <Icon.trending size={13} /> Forecast
          </button>
        </div>
      )}

      <div className="top-actions">
        <button className="btn ghost icon-only" title="Notificações"><Icon.bell /></button>
        <button className="btn" onClick={onTweaks}><Icon.sparkle size={13} /> Tweaks</button>
        <button className="btn primary" onClick={onAddLead}>
          <Icon.plus size={13} /> Novo lead
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { Topbar });
