function Pipeline({ view, leads, onMove, onOpen }) {
  if (view === "list")     return <PipelineList leads={leads} onOpen={onOpen} />;
  if (view === "forecast") return <PipelineForecast leads={leads} />;
  return <PipelineKanban leads={leads} onMove={onMove} onOpen={onOpen} />;
}

function PipelineKanban({ leads, onMove, onOpen }) {
  const [dragId, setDragId] = React.useState(null);
  const [over, setOver] = React.useState(null);

  const byStage = React.useMemo(() => {
    const m = {}; STAGES.forEach(s => m[s.id] = []);
    leads.forEach(l => m[l.stage]?.push(l));
    return m;
  }, [leads]);

  return (
    <div className="pipeline">
      {STAGES.map(s => {
        const items = byStage[s.id] || [];
        const sum = items.reduce((a, b) => a + b.value, 0);
        return (
          <div key={s.id} className="stage-col">
            <div className="stage-hd">
              <span className="dot" style={{ background: s.color }} />
              <span className="nm">{s.name}</span>
              <span className="ct">{items.length}</span>
              <span className="sum">{fmtBRL(sum)}</span>
            </div>
            <div
              className={"stage-bd" + (over === s.id ? " drop-target" : "")}
              onDragOver={(e) => { e.preventDefault(); setOver(s.id); }}
              onDragLeave={() => setOver(o => o === s.id ? null : o)}
              onDrop={(e) => { e.preventDefault(); if (dragId) onMove(dragId, s.id); setOver(null); setDragId(null); }}
            >
              {items.map(l => (
                <LeadCard key={l.id} lead={l} dragging={dragId === l.id}
                  onDragStart={() => setDragId(l.id)}
                  onDragEnd={() => { setDragId(null); setOver(null); }}
                  onClick={() => onOpen(l.id)} />
              ))}
              {items.length === 0 && (
                <div style={{ fontSize:11.5, color:"var(--c-ink-4)", textAlign:"center", padding:"16px 0", border:"1px dashed var(--c-line)", borderRadius: 8 }}>
                  Arraste um lead para cá
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function LeadCard({ lead, dragging, onDragStart, onDragEnd, onClick }) {
  const owner = OWNERS.find(o => o.id === lead.owner);
  return (
    <div className={"lead-card" + (dragging ? " dragging" : "")}
         draggable
         onDragStart={onDragStart}
         onDragEnd={onDragEnd}
         onClick={onClick}>
      <div className="co">
        <CompanyMark logo={lead.logo} />
        <span className="co-name">{lead.company}</span>
        <Avatar owner={owner} size="xs" />
      </div>
      <div className="contact">{lead.contact} · {lead.role}</div>
      <div className="meta">
        <span className="val">{fmtBRL(lead.value)}</span>
        <span className="dim">· {lead.probability}%</span>
        <ScoreBar score={lead.score} />
      </div>
      {lead.nextStep && (
        <div className={"next-step " + (lead.nextStep.state || "")}>
          <Icons.clock />
          <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{lead.nextStep.label}</span>
          <span className="mono" style={{ fontSize: 10.5 }}>{lead.nextStep.due}</span>
        </div>
      )}
    </div>
  );
}

function PipelineList({ leads, onOpen }) {
  return (
    <div className="page">
      <div className="filters-bar">
        <span className="filter-pill"><Icons.filter size={12} /> Estágio: qualquer <Icons.x size={11} className="x" /></span>
        <span className="filter-pill">Owner: todos <Icons.x size={11} className="x" /></span>
        <span className="filter-pill">Valor &gt; R$ 50k <Icons.x size={11} className="x" /></span>
        <span className="filter-pill add"><Icons.plus size={11} /> Adicionar filtro</span>
        <span style={{ marginLeft: "auto", fontSize: 12, color: "var(--c-ink-3)" }}>{leads.length} negócios</span>
      </div>
      <table className="tbl">
        <thead>
          <tr>
            <th className="checkbox-col"><Checkbox /></th>
            <th>Empresa</th>
            <th>Contato</th>
            <th>Estágio</th>
            <th>Valor</th>
            <th>Score</th>
            <th>Prob.</th>
            <th>Owner</th>
            <th>Próxima ação</th>
          </tr>
        </thead>
        <tbody>
          {leads.map(l => {
            const owner = OWNERS.find(o => o.id === l.owner);
            return (
              <tr key={l.id} onClick={() => onOpen(l.id)}>
                <td><Checkbox /></td>
                <td>
                  <div className="co-cell">
                    <CompanyMark logo={l.logo} />
                    <div>
                      <strong>{l.company}</strong>
                      <div style={{fontSize:11, color:"var(--c-ink-3)"}}>{l.segment}</div>
                    </div>
                  </div>
                </td>
                <td>{l.contact}<div style={{fontSize:11,color:"var(--c-ink-3)"}}>{l.role}</div></td>
                <td><StageChip stageId={l.stage} /></td>
                <td className="num">{fmtBRL(l.value)}</td>
                <td><ScoreBar score={l.score} /></td>
                <td className="num dim">{l.probability}%</td>
                <td><Avatar owner={owner} size="xs" /></td>
                <td>
                  <div className={"next-step " + (l.nextStep.state || "")} style={{margin:0,padding:"4px 7px"}}>
                    <Icons.clock />
                    <span>{l.nextStep.due}</span>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function PipelineForecast({ leads }) {
  const byStage = {};
  STAGES.forEach(s => byStage[s.id] = leads.filter(l => l.stage === s.id));
  const total = leads.reduce((a, b) => a + b.value * (b.probability / 100), 0);
  const committed = leads.filter(l => ["negociacao", "ganho"].includes(l.stage)).reduce((a,b) => a + b.value * (b.probability/100), 0);
  const best = leads.reduce((a,b) => a + b.value, 0);

  return (
    <div className="page-pad">
      <div className="page-head">
        <div>
          <div style={{ fontSize: 11, color: "var(--c-ink-3)", textTransform:"uppercase", letterSpacing:".06em" }}>Forecast</div>
          <h1>Fechamento Q2 · 2026</h1>
          <div className="sub">Projeção ponderada por probabilidade, segmentada por estágio.</div>
        </div>
      </div>
      <div className="kpi-row">
        <KPI label="Comprometido"  value={fmtBRL(committed)} delta={`${leads.filter(l => ["negociacao","ganho"].includes(l.stage)).length} negócios`} subtle />
        <KPI label="Forecast ponderado" value={fmtBRL(total)} delta="+12% vs. prev."  up />
        <KPI label="Melhor cenário" value={fmtBRL(best)}      delta="100% conversão" subtle />
        <KPI label="Gap para meta"  value="R$ 1,2M"           delta="−18% a atingir"  up={false} />
      </div>

      <div className="card">
        <div className="card-hd"><h3>Distribuição por estágio</h3></div>
        <div className="card-bd">
          {STAGES.map((s, i) => {
            const items = byStage[s.id];
            const sum = items.reduce((a,b) => a + b.value, 0);
            const weighted = items.reduce((a,b) => a + b.value * (b.probability / 100), 0);
            return (
              <div key={s.id} style={{ padding: "12px 0", borderBottom: i < STAGES.length - 1 ? "1px dashed var(--c-line)" : "none" }}>
                <div className="row" style={{marginBottom:8}}>
                  <span className="dot" style={{ width:8,height:8,borderRadius:"50%",background:s.color }} />
                  <strong style={{fontSize:13}}>{s.name}</strong>
                  <span className="dim" style={{fontSize:11.5}}>· {items.length} negócios</span>
                  <span style={{marginLeft:"auto"}} className="mono">{fmtBRL(sum)}</span>
                  <span className="dim mono" style={{fontSize:11.5, width: 110, textAlign: "right"}}>pond. {fmtBRL(weighted)}</span>
                </div>
                <div style={{display:"flex", gap:3, height:6, borderRadius:3, overflow:"hidden", background:"var(--c-panel-2)"}}>
                  {items.map(l => (
                    <div key={l.id} title={`${l.company} · ${fmtBRL(l.value)}`}
                         style={{ flex: l.value, background: s.color, opacity: 0.4 + (l.probability/100)*0.6 }} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Pipeline });
