// Thin-line icon set — stroke only
const I = (d, extra) => ({ className = "icon", size = 16, ...rest } = {}) =>
  <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {extra}
    <path d={d} />
  </svg>;

const Icons = {
  dashboard: I("M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z"),
  pipeline:  I("M4 6h16M4 12h10M4 18h6"),
  kanban:    I("M4 4h6v16H4zM14 4h6v10h-6z"),
  list:      I("M4 6h16M4 12h16M4 18h16"),
  users:     I("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75", <circle cx="9" cy="7" r="4" />),
  search:    I("M21 21l-4.3-4.3", <circle cx="11" cy="11" r="7" />),
  inbox:     I("M22 12h-6l-2 3h-4l-2-3H2M5 4h14l3 8v8H2v-8z"),
  target:    I("", <><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" /></>),
  zap:       I("M13 2L3 14h9l-1 8 10-12h-9z"),
  reports:   I("M3 3v18h18M7 14l3-3 4 4 6-7"),
  settings:  I("M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z", <circle cx="12" cy="12" r="3" />),
  plus:      I("M12 5v14M5 12h14"),
  filter:    I("M22 3H2l8 9.5V19l4 2v-8.5z"),
  calendar:  I("M8 2v4M16 2v4M3 10h18", <rect x="3" y="4" width="18" height="18" rx="2" />),
  clock:     I("M12 6v6l4 2", <circle cx="12" cy="12" r="10" />),
  phone:     I("M22 16.92v3a2 2 0 0 1-2.18 2 19.86 19.86 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.86 19.86 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.72 2.8a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.28a2 2 0 0 1 2.11-.45c.9.36 1.84.6 2.8.73A2 2 0 0 1 22 16.92z"),
  mail:      I("M22 6l-10 7L2 6", <rect x="2" y="4" width="20" height="16" rx="2" />),
  message:   I("M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"),
  chevronDown: I("M6 9l6 6 6-6"),
  chevronRight: I("M9 6l6 6-6 6"),
  more:      I("", <><circle cx="5" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="19" cy="12" r="1.5" fill="currentColor"/></>),
  x:         I("M18 6L6 18M6 6l12 12"),
  sparkle:   I("M12 3l1.8 4.8L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.2zM19 15l.8 2 2.2.8-2.2.8L19 21l-.8-2.4L16 18l2.2-1z"),
  building:  I("M9 22v-4h6v4M2 22h20M4 22V4h16v18M8 8h2M14 8h2M8 12h2M14 12h2M8 16h2M14 16h2"),
  user:      I("M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2", <circle cx="12" cy="7" r="4" />),
  mapPin:    I("M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z", <circle cx="12" cy="10" r="3" />),
  briefcase: I("M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", <rect x="2" y="6" width="20" height="15" rx="2" />),
  trending:  I("M23 6l-9.5 9.5-5-5L1 18M17 6h6v6"),
  check:     I("M20 6L9 17l-5-5"),
  link:      I("M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"),
  flame:     I("M8.5 14.5A2.5 2.5 0 0 0 11 17c1 0 2-1 2-2s-1-2-2-2-2-1-2-2 1-2 2-2 2 1 2 2c0-3-3-5-3-5s-4 2-4 6a6 6 0 0 0 12 0c0-3-2-5-5-8"),
  bolt:      I("M13 2L3 14h9l-1 8 10-12h-9z"),
  bell:      I("M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"),
  arrowUpRight: I("M7 17L17 7M7 7h10v10"),
  pause:     I("M6 4h4v16H6zM14 4h4v16h-4z"),
  play:      I("M5 3l14 9-14 9z"),
  home:      I("M3 12l9-9 9 9M5 10v10h14V10"),
  menu:      I("M3 6h18M3 12h18M3 18h18"),
  dragHandle: I("M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01"),
};

Object.assign(window, { Icons });
