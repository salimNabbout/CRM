function LeadDetail({ lead, onClose, onStage }) {
  const [tab, setTab] = React.useState("atividades");
  if (!lead) return null;
  const owner = OWNERS.find(o => o.id === lead.owner);

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer">
        <div className="drawer-hd">
          <button className="btn ghost icon-only" onClick={onClose}><Icons.x /></button>
          <span className="crumbs" style={{fontSize:12}}>
            <StageChip stageId={lead.stage} />
            <span className="sep">·</span>
            <span className="dim">{lead.id}</span>
          </span>
          <div style={{marginLeft:"auto"}} className="row" style={{gap:6}}>
            <button className="btn sm"><Icons.phone size={12} /> Ligar</button>
            <button className="btn sm"><Icons.mail size={12} /> E-mail</button>
            <button className="btn sm"><Icons.message size={12} /> WhatsApp</button>
            <button className="btn sm"><Icons.calendar size={12} /> Agendar</button>
            <button className="btn sm icon-only"><Icons.more /></button>
          </div>
        </div>

        <div className="drawer-bd">
          <div className="drawer-main">
            <div className="lead-hero">
              <div className="big-logo">{lead.logo}</div>
              <div style={{flex:1, minWidth:0}}>
                <h2>{lead.company}</h2>
                <div className="sub">{lead.segment} · {lead.city} · {lead.employees} funcionários · {lead.revenue}</div>
                <div className="row" style={{gap:6, marginTop:8}}>
                  <span className="chip accent"><Icons.flame size={10} /> Score {lead.score}</span>
                  <span className="chip">{lead.probability}% de fechamento</span>
                  <span className="chip"><Icons.link size={10} /> {lead.source}</span>
                </div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:11, color:"var(--c-ink-3)"}}>Valor do negócio</div>
                <div className="mono" style={{fontSize:28, fontWeight:500, letterSpacing:"-0.02em"}}>{fmtBRL(lead.value)}</div>
                <div className="dim mono" style={{fontSize:11.5}}>Ponderado: {fmtBRL(lead.value * lead.probability / 100)}</div>
              </div>
            </div>

            <StagePath current={lead.stage} onStage={onStage} />

            <div className="detail-tabs" style={{marginTop: 22}}>
              <button className={tab === "atividades" ? "active" : ""} onClick={() => setTab("atividades")}>
                Atividades <span className="ct">{TIMELINE.length}</span>
              </button>
              <button className={tab === "info" ? "active" : ""} onClick={() => setTab("info")}>Informações</button>
              <button className={tab === "contatos" ? "active" : ""} onClick={() => setTab("contatos")}>
                Contatos <span className="ct">3</span>
              </button>
              <button className={tab === "arquivos" ? "active" : ""} onClick={() => setTab("arquivos")}>
                Arquivos <span className="ct">4</span>
              </button>
              <button className={tab === "notas" ? "active" : ""} onClick={() => setTab("notas")}>Notas</button>
            </div>

            {tab === "atividades" && <ActivityTab />}
            {tab === "info" && <InfoTab lead={lead} />}
            {tab === "contatos" && <ContactsTab lead={lead} />}
            {tab === "arquivos" && <FilesTab />}
            {tab === "notas" && <NotesTab />}
          </div>

          <aside className="drawer-side">
            <div style={{fontSize:11, color:"var(--c-ink-4)", textTransform:"uppercase", letterSpacing:".06em", marginBottom:8}}>Próxima ação</div>
            <div className={"next-step " + (lead.nextStep.state || "")} style={{padding:"10px 12px"}}>
              <Icons.clock />
              <div style={{flex:1}}>
                <div>{lead.nextStep.label}</div>
                <div className="mono" style={{fontSize:10.5, opacity:.8}}>{lead.nextStep.due}</div>
              </div>
            </div>

            <div style={{fontSize:11, color:"var(--c-ink-4)", textTransform:"uppercase", letterSpacing:".06em", margin:"18px 0 8px"}}>Responsável</div>
            <div className="row" style={{gap:10, padding:"8px 0"}}>
              <Avatar owner={owner} size="md" />
              <div style={{flex:1}}>
                <div style={{fontSize:13, fontWeight:500}}>{owner.name}</div>
                <div style={{fontSize:11, color:"var(--c-ink-3)"}}>Account Executive</div>
              </div>
              <button className="btn sm ghost">trocar</button>
            </div>

            <div className="ai-card" style={{marginTop: 14}}>
              <div className="hd"><Icons.sparkle size={12} /> Assistente IA</div>
              <div style={{color: "var(--c-accent-ink)"}}>
                Pedro abriu sua proposta 4× nas últimas 48h. A taxa de conversão em Negociação → Ganho é 62% quando há ligação nos primeiros 5 dias.
              </div>
              <button className="btn sm" style={{marginTop:10, width:"100%"}}>Agendar ligação de fechamento</button>
            </div>

            <div style={{fontSize:11, color:"var(--c-ink-4)", textTransform:"uppercase", letterSpacing:".06em", margin:"18px 0 8px"}}>Informações-chave</div>
            <dl className="kv-grid">
              <dt>Criado em</dt><dd className="mono">{lead.createdAt}</dd>
              <dt>Origem</dt><dd>{lead.source}</dd>
              <dt>Segmento</dt><dd>{lead.segment}</dd>
              <dt>Receita anual</dt><dd className="mono">{lead.revenue}</dd>
              <dt>Funcionários</dt><dd className="mono">{lead.employees}</dd>
              <dt>Último toque</dt><dd>{lead.lastTouch}</dd>
            </dl>

            <div style={{fontSize:11, color:"var(--c-ink-4)", textTransform:"uppercase", letterSpacing:".06em", margin:"18px 0 8px"}}>Cadência</div>
            <div style={{padding:"10px 11px", border:"1px solid var(--c-line)", borderRadius: 7, background:"var(--c-panel)"}}>
              <div className="row"><Icons.bolt size={12} style={{color:"var(--c-accent)"}} /> <strong style={{fontSize:12.5}}>Outbound SP — Logística</strong></div>
              <div style={{display:"flex", gap:3, marginTop:8}}>
                {["✓","✓","✓","●","○","○","○"].map((m,i) =>
                  <div key={i} style={{
                    flex:1, height:6, borderRadius:3,
                    background: m === "✓" ? "var(--c-accent)" : m === "●" ? "var(--c-warn)" : "var(--c-line)"
                  }} />
                )}
              </div>
              <div className="dim mono" style={{fontSize:10.5, marginTop:6}}>Passo 4 de 7 · próx: Qui 14h</div>
            </div>
          </aside>
        </div>
      </div>
    </>
  );
}

function StagePath({ current, onStage }) {
  const idx = STAGES.findIndex(s => s.id === current);
  return (
    <div style={{display:"flex", gap:2, background:"var(--c-panel-2)", border:"1px solid var(--c-line)", borderRadius: 8, padding: 3}}>
      {STAGES.map((s, i) => {
        const done = i < idx, active = i === idx;
        return (
          <button key={s.id} onClick={() => onStage(s.id)}
            style={{
              flex:1, border:"none", cursor:"pointer",
              padding: "7px 8px",
              borderRadius: 5,
              fontSize: 11.5,
              color: active ? "var(--c-bg)" : done ? "var(--c-ink-2)" : "var(--c-ink-4)",
              background: active ? "var(--c-ink)" : done ? "var(--c-panel)" : "transparent",
              display:"flex", alignItems:"center", justifyContent:"center", gap:5,
              fontWeight: active ? 600 : 400,
            }}>
            {done && <Icons.check size={10} />}
            {active && <span className="dot" style={{width:6, height:6, borderRadius:"50%", background:s.color}} />}
            {s.name}
          </button>
        );
      })}
    </div>
  );
}

function ActivityTab() {
  return (
    <div>
      <div className="row" style={{gap:6, marginBottom:14}}>
        <button className="btn sm primary"><Icons.plus size={12} /> Registrar atividade</button>
        <button className="btn sm"><Icons.mail size={12} /> E-mail</button>
        <button className="btn sm"><Icons.phone size={12} /> Ligação</button>
        <button className="btn sm"><Icons.calendar size={12} /> Reunião</button>
        <button className="btn sm"><Icons.message size={12} /> Nota</button>
        <span style={{marginLeft:"auto", fontSize:11.5, color:"var(--c-ink-3)"}}>Filtrar: tudo</span>
      </div>
      <div className="timeline">
        {TIMELINE.map((t, i) => (
          <div key={i} className={"tl-item " + t.type}>
            <span className="dot" />
            <div className="tl-hd">
              <strong>{t.title}</strong>
              <span className="dim">por {t.by}</span>
              <span className="when">{t.when}</span>
            </div>
            <div className="tl-body">{t.body}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InfoTab({ lead }) {
  return (
    <div style={{display:"grid", gridTemplateColumns: "1fr 1fr", gap: 24}}>
      <div>
        <h4 style={{margin:"0 0 8px", fontSize:12, textTransform:"uppercase", letterSpacing:".06em", color:"var(--c-ink-4)"}}>Empresa</h4>
        <dl className="kv-grid">
          <dt>Razão social</dt><dd>{lead.company}</dd>
          <dt>Segmento</dt><dd>{lead.segment}</dd>
          <dt>Cidade</dt><dd>{lead.city}</dd>
          <dt>Funcionários</dt><dd className="mono">{lead.employees}</dd>
          <dt>Receita</dt><dd className="mono">{lead.revenue}</dd>
          <dt>Site</dt><dd>www.{lead.company.toLowerCase().replace(/\s/g,"")}.com.br</dd>
        </dl>
      </div>
      <div>
        <h4 style={{margin:"0 0 8px", fontSize:12, textTransform:"uppercase", letterSpacing:".06em", color:"var(--c-ink-4)"}}>Negócio</h4>
        <dl className="kv-grid">
          <dt>Valor</dt><dd className="mono">{fmtBRL(lead.value)}</dd>
          <dt>Probabilidade</dt><dd className="mono">{lead.probability}%</dd>
          <dt>Fechamento estimado</dt><dd className="mono">30 Jun 2026</dd>
          <dt>Produto</dt><dd>Plataforma CETEM Core + Módulo Analytics</dd>
          <dt>Concorrentes</dt><dd>TOTVS, SAP</dd>
          <dt>Origem</dt><dd>{lead.source}</dd>
        </dl>
      </div>
    </div>
  );
}

function ContactsTab({ lead }) {
  const rows = [
    { name: lead.contact, role: lead.role, email: lead.email, phone: lead.phone, key: true },
    { name: "Renan Albuquerque", role: "CFO", email: `renan@${lead.company.toLowerCase().replace(/\s/g,"")}.com`, phone: "+55 11 99200-7700" },
    { name: "Paula Di Biagio", role: "Gerente de TI", email: `paula@${lead.company.toLowerCase().replace(/\s/g,"")}.com` },
  ];
  return (
    <div style={{display:"flex", flexDirection:"column", gap:8}}>
      {rows.map((c,i) => (
        <div key={i} style={{display:"grid", gridTemplateColumns: "40px 1fr auto", gap:12, alignItems:"center", padding:"12px", border:"1px solid var(--c-line)", borderRadius: 8, background:"var(--c-panel)"}}>
          <Avatar owner={{ initials: c.name.split(" ").map(x=>x[0]).slice(0,2).join(""), hue: 30 + i*90 }} size="md" />
          <div>
            <div style={{fontSize:13, fontWeight:500}}>{c.name} {c.key && <span className="chip accent" style={{marginLeft:6, fontSize:10}}>Decisor</span>}</div>
            <div style={{fontSize:11.5, color:"var(--c-ink-3)"}}>{c.role} · {c.email}{c.phone && " · "+c.phone}</div>
          </div>
          <div className="row" style={{gap:4}}>
            <button className="btn sm icon-only"><Icons.phone size={12} /></button>
            <button className="btn sm icon-only"><Icons.mail size={12} /></button>
            <button className="btn sm icon-only"><Icons.message size={12} /></button>
          </div>
        </div>
      ))}
    </div>
  );
}

function FilesTab() {
  const files = [
    { n: "Proposta_comercial_v3.pdf", s: "1.4 MB", d: "hoje" },
    { n: "NDA_assinado.pdf", s: "320 KB", d: "15 Mar" },
    { n: "Escopo_tecnico_modulo_rastreamento.docx", s: "88 KB", d: "12 Mar" },
    { n: "Apresentacao_demo.pdf", s: "4.2 MB", d: "08 Mar" },
  ];
  return (
    <div>
      {files.map((f,i) => (
        <div key={i} className="row" style={{padding:"10px 12px", border:"1px solid var(--c-line)", borderRadius:8, marginBottom:6, background:"var(--c-panel)"}}>
          <div style={{width:28, height:32, background:"var(--c-panel-2)", borderRadius:4, border:"1px solid var(--c-line)"}} />
          <div style={{flex:1}}>
            <div style={{fontSize:12.5, fontWeight:500}}>{f.n}</div>
            <div style={{fontSize:11, color:"var(--c-ink-3)"}} className="mono">{f.s} · anexado {f.d}</div>
          </div>
          <button className="btn sm ghost"><Icons.arrowUpRight size={12}/></button>
        </div>
      ))}
    </div>
  );
}

function NotesTab() {
  return (
    <div>
      <textarea placeholder="Adicionar nota… @pessoa para mencionar"
        style={{
          width:"100%", minHeight: 88, padding: 12,
          border:"1px solid var(--c-line)", borderRadius: 8,
          background:"var(--c-panel)", color:"var(--c-ink)", fontFamily:"inherit", fontSize:13,
          resize:"vertical"
        }} />
      <div className="row" style={{justifyContent:"flex-end", marginTop:8, gap:6}}>
        <button className="btn sm">Cancelar</button>
        <button className="btn sm primary">Salvar nota</button>
      </div>
      <div style={{marginTop:18, fontSize:12, color:"var(--c-ink-3)"}}>Últimas notas:</div>
      <div style={{padding:"12px 14px", border:"1px solid var(--c-line)", borderRadius:8, marginTop:6, background:"var(--c-panel)"}}>
        <div className="row" style={{marginBottom:6}}>
          <Avatar owner={OWNERS[0]} size="xs" />
          <strong style={{fontSize:12.5}}>Mariana Rocha</strong>
          <span className="dim mono" style={{fontSize:11, marginLeft:"auto"}}>ontem · 11:05</span>
        </div>
        <div style={{fontSize:12.5, color:"var(--c-ink-2)"}}>CFO é bloqueador. Precisamos mostrar payback em 9 meses na próxima reunião — @juliana pode trazer os cases da Hórus?</div>
      </div>
    </div>
  );
}

Object.assign(window, { LeadDetail });
